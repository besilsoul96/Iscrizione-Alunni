/** Automatically generated file. DO NOT MODIFY */
package com.ismonnet.openjm;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}