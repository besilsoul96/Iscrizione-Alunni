import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.StringTokenizer;


public class Client {

	public static void main(String[] args) {
		Socket  connessione  =  null;
		String  server  =  "localhost";
		int  port  =  3333;
		InputStreamReader  in,  input;
		BufferedReader  sIN,  tastiera;
		OutputStream  out;
		PrintWriter  sOUT;
		String msgRicevuto;
		StringTokenizer st;
		try
		{
			connessione  =  new  Socket(server,  port);
			System.out.println("Connessione  eseguita.");
		}
		catch  (IOException  e)
		{
			System.out.println(e);
			System.exit(-1);
		}
		
		try
		{
			//flusso  in  ingresso  da  socket
			in  =  new  InputStreamReader(connessione.getInputStream());
			sIN  =  new  BufferedReader(in);
			//  flusso  in  uscita  su  socket
			out  =  connessione.getOutputStream();
			sOUT  =  new  PrintWriter(out);
			//  flusso  in  ingresso  da  tastiera
			input  =  new  InputStreamReader(System.in);
			tastiera  =  new  BufferedReader(input);
			
			
			System.out.println("Vuoi prenotare [P] o visualizzare una prenotazione gia effettuata [V]? ");
			String scelta = tastiera.readLine();
			
			sOUT.println(scelta);
			sOUT.flush();
			
			String msgOK = sIN.readLine();
			
			if(scelta.toUpperCase().equals("P"))
			{
				boolean avanti = false;
				
					System.out.println("Sei un referente [R] o un genitore [G]? ");
					String tipo = tastiera.readLine().toUpperCase();
					
					String giorni = sIN.readLine();
					st = new StringTokenizer(giorni, ";");
					
					String Strconta = st.nextToken();
					int conta = Integer.parseInt(Strconta);
					for(int i =0; i<conta ; i++)
					{
						String giorno = st.nextToken();
						String numGiorno=st.nextToken();
						String mese = st.nextToken();
						String anno = st.nextToken();
						String postiD = st.nextToken();
						
						System.out.println(giorno + " "+ numGiorno + " " + mese + "  posti disponibili: " + postiD + "      ["+ i +"]");
					}
					
					System.out.println("Scegli il giorno: ");
					
					String giornoScelto = tastiera.readLine();
					
					System.out.println("INSERIMENTO DATI REFERENTE/GENITORE:  ");
					System.out.println("Nome: ");
					String nomeP = tastiera.readLine();
					System.out.println("Cognome: ");
					String cognomeP = tastiera.readLine();
					System.out.println("Telefono: ");
					String telefono = tastiera.readLine();
					System.out.println("E-mail: ");
					String email = tastiera.readLine();
					System.out.println("Num. posti d prenotare: ");
					int postiP = Integer.parseInt(tastiera.readLine());
					
					System.out.println("INSERIMENTO DATI STUDENTE/I:  ");
					ArrayList<String> nomiS = new ArrayList<String>();
					ArrayList<String> cognomiS = new ArrayList<String>();
					for(int i=1; i<=postiP; i++)
					{
						System.out.println("Nome studente "+ i +": ");
						nomiS.add(tastiera.readLine());
						System.out.println("Cognome studente "+ i +": ");
						cognomiS.add(tastiera.readLine());
					}
					System.out.println("Scuola provenienza: ");
					String scuola = tastiera.readLine();
					
					
					
					
					
					System.out.println("RIASSUNTO PRENOTAZIONE: ");
					System.out.println("Dati prenotatore: ");
					System.out.println("Nome: " + nomeP);
					System.out.println("Cognome: " + cognomeP);
					
					System.out.println("Dati studenti: ");
					
					for(int i=1; i <= nomiS.size();i++)
					{
						System.out.println("Nome studente "+ i +": " + nomiS.get(i-1));
						
						System.out.println("Cognome studente "+ i +": " + cognomiS.get(i-1));
						
					}
					
					System.out.println("Premi [C] per confermare o [E] per uscire: ");
					String conferma = tastiera.readLine();
					if(conferma.toUpperCase().equals("C"))
					{
						avanti = true;
						String msgDaInviare = scelta +";"+ giornoScelto+";" + tipo +";"+ nomeP +";"+ cognomeP +";"+telefono+";"+ email +";"+ postiP +";S;";
						for(int i=0; i<nomiS.size();i++)
						{
							msgDaInviare += nomiS.get(i) +";" + cognomiS.get(i) +";";
						}
						
						msgDaInviare += scuola;
						
						sOUT.println(msgDaInviare);
						sOUT.flush();
						
						System.out.println(sIN.readLine());
					}
					else
					{
						System.out.println("Applicazione in chiusura");
					}
				
				
			}
			else
			{
				System.out.println("Inserire dati prenotatore: ");
				System.out.println("Nome: ");
				String nomeP = tastiera.readLine();
				System.out.println("Cognome: ");
				String cognomeP = tastiera.readLine();
				String msgDaInviare = scelta+";"+nomeP+";"+cognomeP;
				
				sOUT.println(msgDaInviare);
				sOUT.flush();
				
				
				String risultato = sIN.readLine();
				System.out.println(risultato);
			}
			
		}	
		catch  (IOException  e)
		{
			System.out.println(e);
		}
		try
		{
			connessione.close();
		}
		catch (IOException e)
		{
			System.out.println(e);
		}
	}

}
