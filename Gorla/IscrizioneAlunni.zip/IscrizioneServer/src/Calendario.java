import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.*;

public class Calendario {
	
	FileReader posti;
	BufferedReader buffer; 
	ArrayList<String> Lposti = new ArrayList<String>();
	
	public Calendario()	//Costruttore che mette ci� che c'� nel file nella lista
	{
		try {
			posti = new FileReader("posti.txt");
			buffer = new BufferedReader(posti);
			while(true)
			{
				String s;
				s = buffer.readLine();
				if(s==null) break;             //se non ci sono pi� caratteri termino
		        else
		        {
		        	Lposti.add(s);
		        }
			}
				
			} catch (IOException e) {
				e.printStackTrace();
			}  
	        
	}
	
	
	
	public String getPosti()	//Restituisco una stringa con tutti i giorni, ovvero tutta la lista in un'unica stringa
	{
		String posti;
		posti = String.valueOf(Lposti.size())+";";
		for(int i=0; i<Lposti.size();i++)
		{
			posti += Lposti.get(i);
		}
		return posti;
	}
	
	public void togliPosti(int numPosti, int posG)	//Tolgo i posti diponibili che sono stati appena prenotati ad una data
	{
		StringTokenizer temp = new StringTokenizer(Lposti.get(posG), ";");
		String giorno = temp.nextToken();
		String numGiorno=temp.nextToken();
		String mese = temp.nextToken();
		String anno = temp.nextToken();
		String postiD = temp.nextToken();
		
		int postiNuovi = Integer.parseInt(postiD) - numPosti;
		String str =  giorno+";"+numGiorno+";"+mese+";"+anno+";"+String.valueOf(postiNuovi)+";";
		Lposti.set(posG,str );
		
	}
	
	public void caricaLista() //mi serve quando uso il metodo TogliPosti, perch� riscrive il file con quello che c'� scritto nella lista
	{
		
		try {
		
			
			FileOutputStream writer = new FileOutputStream("posti.txt");
			PrintStream scrivi= new PrintStream(writer);
			
			for(int i=0; i<Lposti.size();i++)
			{
				scrivi.println(Lposti.get(i));
			}
			
			
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		
	}
	
	public String getGiorno(int pos)	//Mi ristituisce un determinato giorno
	{
		String str = Lposti.get(pos);	
		StringTokenizer st = new StringTokenizer(str, ";");
		String giorno = st.nextToken();
		String numG = st.nextToken();
		String mese = st.nextToken();
		String anno = st.nextToken();
		
		return giorno +" " + numG +" "+mese+" " +anno;
	}
	
	
	
}
