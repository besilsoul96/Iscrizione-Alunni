import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class ThreadIscrizione implements Runnable {
	private  Socket  connessione  =  null;
	private  InputStreamReader  in;
	private  BufferedReader  sIN;
	private  OutputStream  out;
	private  PrintWriter  sOUT;
	private  BufferedReader  fIN;
	String msgRicevuto;
	String msgDaInviare;
	Calendario c;
	Prenotazione p;
	
	
	public ThreadIscrizione(Socket conn)
	{
		try
		{
			connessione = conn;
			//  apre  i  flussi  in  uscita  e  in  ingresso  dalla  socket
			//  flusso  in  uscita  su  socket
			out  =  connessione.getOutputStream();
			sOUT  =  new  PrintWriter(out);
			//  flusso  in  ingresso  da  socket
			in  =  new  InputStreamReader(connessione.getInputStream());
			sIN  =  new  BufferedReader(in);
			c = new Calendario();
			p= new Prenotazione();
						
		}	
		catch  (IOException  e)
		{
			System.out.println(e);
		}
		
		new  Thread(this).start();
	}
	
	public void run()
	{
		try {
				
			
			
			msgRicevuto = sIN.readLine();
			//StringTokenizer st = new StringTokenizer(msgRicevuto, ";");
			//System.out.println(msgRicevuto);
			//String scelta = st.nextToken();
			sOUT.println("ok");
			sOUT.flush();
			
			if(msgRicevuto.toUpperCase().equals("P"))
			{
				msgDaInviare = c.getPosti();
				sOUT.println(msgDaInviare);
				sOUT.flush();
				
				msgRicevuto = sIN.readLine();
				if(msgRicevuto == null)
				{
					System.out.println("Client ha chiuso l'applicazione.");
				}
				else
				{
					
					StringTokenizer st = new StringTokenizer(msgRicevuto, ";");
					
					//System.out.println(msgRicevuto);
					
					String scelta = st.nextToken();
					int Indicegiorno = Integer.parseInt(st.nextToken());
					String tipo = st.nextToken();
					String nomeP = st.nextToken();
					String cognomeP = st.nextToken();
					String telefono = st.nextToken();
					String email = st.nextToken();
					int postiP  = Integer.parseInt(st.nextToken());
					String s = st.nextToken();
					ArrayList<String> nomiS = new ArrayList<String>();
					ArrayList<String> cognomiS = new ArrayList<String>();
					for(int i=0; i<postiP; i++)
					{
						nomiS.add(st.nextToken());
						cognomiS.add(st.nextToken());
					}
					String scuola = st.nextToken();
					
					c.togliPosti(postiP,Indicegiorno);
					c.caricaLista();
					p.ScriviPrenotazione(msgRicevuto);
					msgDaInviare = "Prenotazione avvenuta con successo";
					sOUT.println(msgDaInviare);
					sOUT.flush();
				}
				}
				else
				{
					
					msgRicevuto = sIN.readLine();
					StringTokenizer st = new StringTokenizer(msgRicevuto, ";");
					
					String scelta = st.nextToken();
					String nomeP = st.nextToken();
					String cognomeP = st.nextToken();
					String ris = p.TrovaPrenotazione(nomeP, cognomeP);
					//System.out.println(ris);
					if(ris.equals("no"))
					{
						sOUT.println("Nessuna prenotazione corrispondente.");
						sOUT.flush();
					}
					else
					{
						
						StringTokenizer st2 = new StringTokenizer(ris,";");
						String pov = st2.nextToken();
						int Indicegiorno = Integer.parseInt(st2.nextToken());
						String tipo = st2.nextToken();
						String nome = st2.nextToken();
						String cognome = st2.nextToken();
						String telefono = st2.nextToken();
						String email = st2.nextToken();
						int postiP  = Integer.parseInt(st2.nextToken());
						String s = st2.nextToken();
						ArrayList<String> nomiS = new ArrayList<String>();
						ArrayList<String> cognomiS = new ArrayList<String>();
						for(int i=0; i<postiP; i++)
						{
							nomiS.add(st2.nextToken());
							cognomiS.add(st2.nextToken());
						}
						String scuola = st2.nextToken();
						
						String giorno = c.getGiorno(Indicegiorno);
						
						String strDaInviare ="Trovata una prenotazione a suo nome il " + giorno + " di " + postiP +" posti.";
						//System.out.println(msgDaInviare);
						
						
						sOUT.println(strDaInviare);
						sOUT.flush();
						
					}
					
				
			}
		
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
