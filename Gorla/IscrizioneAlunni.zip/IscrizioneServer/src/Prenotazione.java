import java.io.*;
import java.util.*;


public class Prenotazione  {
	
	FileReader FilePrenota;
	BufferedReader buffer; 
	FileOutputStream writer;
	PrintStream scrivi;
	ArrayList<String> LPrenotazione = new ArrayList<String>();
	
	public Prenotazione(){		//Costruttore che mette ci� che c'� nel file nella lista
		try {
			
			FilePrenota = new FileReader("prenotazione.txt");
			buffer = new BufferedReader(FilePrenota);
			while(true)
			{
				String s = buffer.readLine();   //leggo
		        if(s==null) break;             //se non ci sono pi� caratteri termino
		        else
		        {
		        	LPrenotazione.add(s);
		        }
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	
	public void ScriviPrenotazione(String str)		//Scrive sul file una nuova prenotazione
	{
		try {
			
			writer = new FileOutputStream("prenotazione.txt", true);
			scrivi = new PrintStream(writer);
			scrivi.println(str);
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
	}
	
	public String TrovaPrenotazione(String nome, String cognome)	//Ricerca nella lista una prenotazione effettuata
	{
		for(int i=0; i<LPrenotazione.size(); i++)
		{
			StringTokenizer st = new StringTokenizer(LPrenotazione.get(i), ";");
			String scelta = st.nextToken();
			int Indicegiorno = Integer.parseInt(st.nextToken());
			String tipo = st.nextToken();
			String nomeP = st.nextToken();
			String cognomeP = st.nextToken();
			
			if(nomeP.equals(nome) && cognomeP.equals(cognome))
			{
				return LPrenotazione.get(i);
			}
		}
		return "no";
	}
	
	
}
